// Flappy Fox — Blue Fox Games (Adjusted spacing + smaller player)
// Put logo.png in same folder.

(() => {
  // DOM
  const canvas = document.getElementById('gameCanvas');
  const ctx = canvas.getContext('2d', { alpha: false });

  const uiOverlay = document.getElementById('uiOverlay');
  const startBtn = document.getElementById('startBtn');
  const howBtn = document.getElementById('howBtn');
  const gameOverOverlay = document.getElementById('gameOverOverlay');
  const restartBtn = document.getElementById('restartBtn');
  const finalScoreEl = document.getElementById('finalScore');
  const bestScoreEl = document.getElementById('bestScore');
  const shareBtn = document.getElementById('shareBtn');
  const muteBtn = document.getElementById('muteBtn');
  const toast = document.getElementById('toast');

  // Assets
  const logoImg = new Image();
  logoImg.src = 'logo.png';

  // Config — pipeSpacingMs increased and made variable; birdSizeRatio reduced
  const CONFIG = {
    pipeWidthRatio: 0.14,
    pipeGapRatio: 0.26,
    pipeSpacingMs: 1800,        // base spacing (increased)
    pipeSpacingRandomAdd: 800,  // extra random ms added to base for variety
    basePipeSpeed: 220,
    gravity: 1400,
    flapVel: -420,
    birdSizeRatio: 0.06,        // <-- player a bit smaller
    particleLimit: 120,
    particleLifetime: 620,
    startDelay: 280,
    dprCap: 2,
    topSpawnMarginRatio: 0.12,
    bottomSpawnMarginRatio: 0.08
  };

  // State
  let dpr = Math.min(window.devicePixelRatio || 1, CONFIG.dprCap);
  let canvasW = 800, canvasH = 600;
  let running = false, started = false;
  let lastTime = 0, spawnTimer = 0, nextSpawnInterval = CONFIG.pipeSpacingMs, pipes = [], score = 0;
  let best = parseInt(localStorage.getItem('flappyFoxHighscore') || '0', 10);
  let muted = localStorage.getItem('flappyFoxMuted') === '1';

  // Bird (relative coords)
  const bird = { xRel: 0.26, yRel: 0.48, vy: 0, w: 56, h: 56, angle: 0 };
  const particles = [];

  // Audio helpers
  let audioCtx = null;
  function ensureAudio() { if (!audioCtx) audioCtx = new (window.AudioContext || window.webkitAudioContext)(); }
  function sfxTone(freq=600, length=0.06, type='sine', vol=0.08) {
    if (muted) return;
    try {
      ensureAudio();
      const o = audioCtx.createOscillator();
      const g = audioCtx.createGain();
      o.type = type; o.frequency.value = freq;
      o.connect(g); g.connect(audioCtx.destination);
      const now = audioCtx.currentTime;
      g.gain.setValueAtTime(0.0001, now);
      g.gain.exponentialRampToValueAtTime(vol, now + 0.01);
      o.start(now);
      g.gain.exponentialRampToValueAtTime(0.0001, now + length + 0.02);
      o.stop(now + length + 0.03);
    } catch (e) {}
  }
  const sfxHit = ()=>sfxTone(160,0.12,'sine',0.12);
  const sfxFlap = ()=>sfxTone(900,0.06,'triangle',0.08);
  const sfxPoint = ()=>sfxTone(1300,0.04,'sine',0.09);

  // Resize
  function resizeCanvas() {
    const rect = canvas.getBoundingClientRect();
    dpr = Math.min(window.devicePixelRatio || 1, CONFIG.dprCap);
    canvasW = Math.round(rect.width);
    canvasH = Math.round(rect.height);
    canvas.width = Math.round(canvasW * dpr);
    canvas.height = Math.round(canvasH * dpr);
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  }
  window.addEventListener('resize', ()=>{ resizeCanvas(); drawStatic(); initClouds(); });

  function rand(min,max){ return Math.random()*(max-min)+min; }
  function clamp(v,a,b){ return Math.max(a, Math.min(b, v)); }
  function showToast(text, ms=900){ if(!toast) return; toast.textContent=text; toast.classList.remove('hidden'); clearTimeout(toast._t); toast._t = setTimeout(()=>toast.classList.add('hidden'), ms); }

  // Clouds
  const clouds = [];
  function initClouds(){
    clouds.length = 0;
    const count = Math.max(4, Math.floor(canvasW / 220));
    for (let i=0;i<count;i++) clouds.push({ x: rand(0,canvasW), y: rand(24,canvasH*0.45), scale: rand(0.6,1.4), speed: rand(6,22) });
  }

  // Spawn pipe — same margins but spawn timing now uses nextSpawnInterval
  function spawnPipe(){
    const gap = Math.round(canvasH * CONFIG.pipeGapRatio);
    const topMargin = Math.round(canvasH * CONFIG.topSpawnMarginRatio);
    const bottomMargin = Math.round(canvasH * CONFIG.bottomSpawnMarginRatio);
    const minY = topMargin + Math.floor(gap/2);
    const maxY = canvasH - bottomMargin - Math.floor(gap/2);
    const gapY = Math.round(rand(minY, Math.max(minY+10, maxY)));
    pipes.push({ x: canvasW + 10, gapY, gap, passed:false });
  }

  // Particles
  function spawnParticle(x,y,color='#ffcf6e'){ if(particles.length>=CONFIG.particleLimit) return; particles.push({ x,y, vx:rand(-80,80), vy:rand(-240,-60), life:CONFIG.particleLifetime, age:0, size:rand(4,10), color }); }
  function updateParticles(dt){ for(let i=particles.length-1;i>=0;i--){ const p=particles[i]; p.age+=dt*1000; if(p.age>=p.life){ particles.splice(i,1); continue; } p.vy += 800*dt; p.x += p.vx*dt; p.y += p.vy*dt; } }

  // Reset / start / gameover
  function reset(){
    running = false; started = false; pipes=[]; score=0;
    bird.vy = 0; bird.yRel = 0.48; bird.angle = 0;
    spawnTimer = 0; lastTime = 0; particles.length = 0;
    // next spawn interval initial randomization for spacing variety
    nextSpawnInterval = CONFIG.pipeSpacingMs + Math.round(rand(0, CONFIG.pipeSpacingRandomAdd));
    updateBestUI(); resizeCanvas(); initClouds(); drawStatic();
    uiOverlay.classList.remove('hidden'); gameOverOverlay.classList.add('hidden');
  }

  function start(){
    running = true; started = true;
    score = 0; pipes = [];
    bird.vy = 0; bird.yRel = 0.48; bird.angle = 0;
    spawnTimer = -CONFIG.startDelay;
    lastTime = performance.now();
    // randomize first interval a bit so it's not always identical
    nextSpawnInterval = CONFIG.pipeSpacingMs + Math.round(rand(0, CONFIG.pipeSpacingRandomAdd));
    uiOverlay.classList.add('hidden'); gameOverOverlay.classList.add('hidden');
    requestAnimationFrame(loop);
  }

  function gameOver(){
    running = false;
    finalScoreEl.textContent = score;
    if (score > best) { best = score; localStorage.setItem('flappyFoxHighscore', String(best)); }
    updateBestUI();
    sfxHit();
    gameOverOverlay.classList.remove('hidden');
    const bx = bird.xRel * canvasW, by = bird.yRel * canvasH;
    for (let i=0;i<18;i++) spawnParticle(bx, by, '#ff9476');
  }

  // Flap
  function flap(){
    if (!running && !started) { start(); sfxFlap(); return; }
    if (!running && started) return;
    bird.vy = CONFIG.flapVel;
    sfxFlap();
    const bx = bird.xRel * canvasW, by = bird.yRel * canvasH;
    for (let i=0;i<6;i++) spawnParticle(bx - bird.w*0.5, by + bird.h*0.15, '#ffd97f');
  }

  // Collision
  function checkCollision(){
    const bx = bird.xRel * canvasW, by = bird.yRel * canvasH;
    const bw = bird.w, bh = bird.h;
    if (by + bh/2 >= canvasH - 4) return true;
    if (by - bh/2 <= 0) return true;
    const pipeW = Math.round(canvasW * CONFIG.pipeWidthRatio);
    for (const p of pipes) {
      if (bx + bw/2 > p.x && bx - bw/2 < p.x + pipeW) {
        const topH = p.gapY - Math.round(p.gap/2);
        const bottomY = p.gapY + Math.round(p.gap/2);
        if (by - bh/2 < topH || by + bh/2 > bottomY) return true;
      }
    }
    return false;
  }

  // Drawing (same robust drawing as before)
  function drawStatic(){
    ctx.clearRect(0,0,canvasW,canvasH);
    const g = ctx.createLinearGradient(0,0,0,canvasH); g.addColorStop(0,'#9be7ff'); g.addColorStop(1,'#6fc9f4'); ctx.fillStyle = g; ctx.fillRect(0,0,canvasW,canvasH);
    ctx.fillStyle = '#4c9bd2'; ctx.fillRect(0, canvasH - Math.round(canvasH*0.07), canvasW, Math.round(canvasH*0.07));
    ctx.fillStyle = 'rgba(3,36,56,0.9)'; ctx.font = '600 18px system-ui'; ctx.textAlign='center'; ctx.fillText('Tap · Click · Space', canvasW/2, Math.round(canvasH*0.12));
  }

  function drawFrame(dt){
    const g = ctx.createLinearGradient(0,0,0,canvasH); g.addColorStop(0,'#9be7ff'); g.addColorStop(1,'#6fc9f4'); ctx.fillStyle = g; ctx.fillRect(0,0,canvasW,canvasH);

    ctx.globalAlpha = 0.95;
    for (const c of clouds) { c.x -= c.speed * dt * 0.06; if (c.x < -200) c.x = canvasW + 120; drawCloud(c.x, c.y, c.scale); }
    ctx.globalAlpha = 1;

    drawHills();
    drawPipes();

    ctx.fillStyle = '#4c9bd2';
    ctx.fillRect(0, canvasH - Math.round(canvasH*0.07), canvasW, Math.round(canvasH*0.07));

    // particles
    ctx.save();
    ctx.globalCompositeOperation = 'lighter';
    for (const p of particles) {
      const alpha = 1 - (p.age / p.life);
      ctx.globalAlpha = clamp(alpha, 0, 1);
      ctx.fillStyle = p.color;
      ctx.beginPath();
      ctx.arc(p.x, p.y, p.size * (0.6 + alpha * 0.6), 0, Math.PI*2);
      ctx.fill();
    }
    ctx.restore();
    ctx.globalAlpha = 1;

    // bird
    const bx = bird.xRel * canvasW, by = bird.yRel * canvasH;
    ctx.save(); ctx.translate(bx, by); ctx.rotate(bird.angle);
    if (logoImg.complete) ctx.drawImage(logoImg, -bird.w/2, -bird.h/2, bird.w, bird.h);
    else { ctx.fillStyle='#ffcf6e'; ctx.beginPath(); ctx.arc(0,0,bird.w/2,0,Math.PI*2); ctx.fill(); }
    ctx.restore();

    // score
    ctx.fillStyle = '#022'; ctx.font = '700 20px system-ui'; ctx.textAlign = 'center'; ctx.fillText(`${score}`, canvasW/2, 34);
    ctx.textAlign = 'right'; ctx.font = '600 14px system-ui'; ctx.fillText(`Best: ${best}`, canvasW - 12, 24);
  }

  function drawCloud(x,y,scale=1){
    ctx.fillStyle='rgba(255,255,255,0.95)';
    const w=140*scale, h=48*scale, cx=x;
    ctx.beginPath(); ctx.arc(cx - w*0.28, y, h*0.5, 0, Math.PI*2);
    ctx.arc(cx, y - h*0.12, h*0.62, 0, Math.PI*2);
    ctx.arc(cx + w*0.30, y, h*0.48, 0, Math.PI*2);
    ctx.rect(cx - w*0.6, y, w*1.2, h*0.5);
    ctx.fill();
  }

  function drawHills(){
    ctx.fillStyle='#83c7f0'; ctx.beginPath(); ctx.moveTo(0, canvasH*0.62); ctx.quadraticCurveTo(canvasW*0.25, canvasH*0.52, canvasW*0.5, canvasH*0.64); ctx.quadraticCurveTo(canvasW*0.72, canvasH*0.72, canvasW, canvasH*0.6); ctx.lineTo(canvasW, canvasH); ctx.lineTo(0, canvasH); ctx.closePath(); ctx.fill();
    ctx.fillStyle='#62b8e6'; ctx.beginPath(); ctx.moveTo(0, canvasH*0.7); ctx.quadraticCurveTo(canvasW*0.3, canvasH*0.6, canvasW, canvasH*0.75); ctx.lineTo(canvasW, canvasH); ctx.lineTo(0, canvasH); ctx.closePath(); ctx.fill();
  }

  function drawPipes(){
    const pipeW = Math.round(canvasW * CONFIG.pipeWidthRatio);
    const capH = 14;
    for (const p of pipes) {
      ctx.save();
      ctx.globalCompositeOperation = 'source-over';
      ctx.globalAlpha = 1;

      const rawTopH = p.gapY - Math.round(p.gap/2);
      const topH = Math.max(0, rawTopH);
      const bottomY = p.gapY + Math.round(p.gap/2);

      // shadow
      ctx.beginPath();
      roundRectPath(Math.round(p.x + 6), 4, pipeW, Math.max(8, topH - 4), 6);
      ctx.fillStyle = 'rgba(0,0,0,0.12)';
      ctx.fill();

      ctx.beginPath();
      roundRectPath(Math.round(p.x + 6), bottomY + 6, pipeW, Math.max(8, canvasH - bottomY - 10), 6);
      ctx.fill();

      // body gradient
      const g = ctx.createLinearGradient(0,0,0,canvasH);
      g.addColorStop(0, '#49a94b');
      g.addColorStop(1, '#2b8a3e');

      // top
      if (topH > 0) {
        ctx.beginPath();
        roundRectPath(Math.round(p.x), 0, pipeW, topH, 8);
        ctx.fillStyle = g; ctx.fill();
      }

      // bottom
      ctx.beginPath();
      roundRectPath(Math.round(p.x), bottomY, pipeW, Math.max(8, canvasH - bottomY), 8);
      ctx.fillStyle = g; ctx.fill();

      // caps
      ctx.fillStyle = '#2a7e36';
      if (topH > 0) {
        const capTopY = Math.max(0, topH - capH);
        const capTopH = Math.min(capH, topH);
        ctx.fillRect(Math.round(p.x), capTopY, pipeW, capTopH);
      }
      const capBottomH = Math.min(capH, Math.max(0, canvasH - bottomY));
      if (capBottomH > 0) ctx.fillRect(Math.round(p.x), bottomY, pipeW, capBottomH);

      ctx.restore();
    }
  }

  function roundRectPath(x,y,w,h,r){
    if (w <= 0 || h <= 0) return;
    ctx.moveTo(x + r, y);
    ctx.arcTo(x + w, y, x + w, y + h, r);
    ctx.arcTo(x + w, y + h, x, y + h, r);
    ctx.arcTo(x, y + h, x, y, r);
    ctx.arcTo(x, y, x + w, y, r);
    ctx.closePath();
  }

  // Loop
  function loop(ts){
    if (!lastTime) lastTime = ts;
    const dt = Math.min((ts - lastTime) / 1000, 0.034);
    lastTime = ts;

    bird.w = Math.round(canvasW * CONFIG.birdSizeRatio);
    bird.h = bird.w;

    spawnTimer += dt * 1000;
    const currentPipeSpeed = CONFIG.basePipeSpeed + Math.floor(score / 6) * 8;
    if (spawnTimer >= nextSpawnInterval) {
      spawnTimer = 0;
      spawnPipe();
      // set next spawn with base + random extra so pipes can be farther apart
      nextSpawnInterval = CONFIG.pipeSpacingMs + Math.round(rand(0, CONFIG.pipeSpacingRandomAdd));
    }

    for (const p of pipes) {
      p.x -= currentPipeSpeed * dt;
      if (!p.passed && p.x + Math.round(canvasW * CONFIG.pipeWidthRatio) < bird.xRel * canvasW) {
        p.passed = true;
        score++;
        sfxPoint();
      }
    }
    pipes = pipes.filter(p => p.x + Math.round(canvasW * CONFIG.pipeWidthRatio) > -80);

    bird.vy += CONFIG.gravity * dt;
    bird.yRel += (bird.vy * dt) / canvasH;
    bird.angle = clamp(bird.vy / 1000, -0.9, 0.9);

    updateParticles(dt);
    for (const c of clouds) { c.x -= (currentPipeSpeed * 0.06) * dt; if (c.x < -200) c.x = canvasW + rand(40,160); }

    if (running && checkCollision()) gameOver();

    drawFrame(dt);
    if (running) requestAnimationFrame(loop);
  }

  // Input
  function onKeyDown(e){ if (e.code === 'Space' || e.code === 'Enter') { if (e.repeat) return; e.preventDefault(); flap(); } }
  function onPointerDown(e){ flap(); }

  // UI events
  startBtn.addEventListener('click', ()=>start());
  restartBtn.addEventListener('click', ()=>start());
  howBtn.addEventListener('click', ()=>showToast('Tap to flap. Avoid pipes. Score by passing pipes.',2500));
  shareBtn.addEventListener('click', ()=>{ const text = `I scored ${score} in Flappy Fox by Blue Fox Games!`; if (navigator.share) navigator.share({title:'Flappy Fox', text}).catch(()=>{}); else if (navigator.clipboard) navigator.clipboard.writeText(text).then(()=>showToast('Score copied!')); else prompt('Copy your score:', text); });

  function updateMuteUI(){ muteBtn.textContent = muted ? '🔇' : '🔊'; muteBtn.setAttribute('aria-pressed', muted ? 'true' : 'false'); }
  muteBtn.addEventListener('click', ()=>{ muted = !muted; localStorage.setItem('flappyFoxMuted', muted ? '1':'0'); updateMuteUI(); showToast(muted ? 'Muted' : 'Sound on', 900); });
  updateMuteUI();

  // Init
  window.addEventListener('keydown', onKeyDown);
  canvas.addEventListener('pointerdown', onPointerDown);

  function updateBestUI(){ bestScoreEl.textContent = best; }
  function init(){ resizeCanvas(); initClouds(); drawStatic(); updateBestUI(); }
  logoImg.onload = ()=>{ resizeCanvas(); drawStatic(); };
  logoImg.onerror = ()=>{};
  init();
  reset();

  // debug hooks
  window._flappyFox = { reset, start, spawnPipe };

})();